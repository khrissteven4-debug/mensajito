let pantallaAnterior = null; // Para recordar la pantalla anterior

function startStory() {
  const nombre = document.getElementById("nombre").value.trim();
  const edad = document.getElementById("edad").value.trim();
  const estado = document.getElementById("estado").value;

  if (nombre === "" || edad === "") {
    alert("Por favor completa tu nombre y edad 😊");
    return;
  }

  window.userData = { nombre, edad, estado };
  nextScreen("screenHola");
}

function nextScreen(id) {
  const actual = document.querySelector(".screen.active");
  if (actual) pantallaAnterior = actual.id;

  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  const el = document.getElementById(id);
  if (el) el.classList.add("active");
}

function volverAnterior() {
  if (pantallaAnterior) nextScreen(pantallaAnterior);
}

function borrarSitio() {
  document.body.innerHTML = "<h1 style='text-align:center; color:white; margin-top:50px;'>El sitio fue borrado 💔</h1>";
  document.body.style.background = "black";
}

// Chocolates cayendo
function crearChocolate() {
  const chocolate = document.createElement("div");
  chocolate.classList.add("chocolate");
  chocolate.innerText = "🍫";
  chocolate.style.left = Math.random() * 100 + "vw";
  chocolate.style.fontSize = Math.random() * 20 + 20 + "px";
  chocolate.style.position = "absolute";
  chocolate.style.zIndex = 1000;
  document.getElementById("chocolates").appendChild(chocolate);

  setTimeout(() => chocolate.remove(), 5000);
}
setInterval(crearChocolate, 500);

function crearLoro() {
  const loro = document.createElement("div");
  loro.classList.add("loro");
  loro.innerText = "🦜"; // Emoji de loro, puedes cambiarlo por una imagen
  loro.style.top = Math.random() * 80 + "vh"; // posición vertical aleatoria
  loro.style.fontSize = Math.random() * 20 + 20 + "px"; // tamaño aleatorio
  document.getElementById("chocolates").appendChild(loro);

  // eliminar el loro después de 8 segundos
  setTimeout(() => {
    loro.remove();
  }, 8000);
}

// cada 3 segundos aparece un loro nuevo
setInterval(crearLoro, 3000);

function mostrarCorazones() {
  const efecto = document.getElementById("corazonEffect");
  efecto.classList.remove("hidden");

  // generar corazones animados
  for (let i = 0; i < 30; i++) {
    const heart = document.createElement("div");
    heart.classList.add("corazon");
    heart.innerText = "❤️";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.animationDuration = (2 + Math.random() * 3) + "s";
    heart.style.fontSize = (20 + Math.random() * 30) + "px";
    efecto.appendChild(heart);

    // remover después de animación
    setTimeout(() => heart.remove(), 5000);
  }
}
